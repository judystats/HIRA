CREATE TABLE #Codesets (
  codeset_id int NOT NULL,
  concept_id bigint NOT NULL
)
;

INSERT INTO #Codesets (codeset_id, concept_id)
SELECT 0 as codeset_id, c.concept_id FROM (select distinct I.concept_id FROM
( 
  select concept_id from @vocabulary_database_schema.CONCEPT where concept_id in (45548416,80497,36713107,36713108,4167097,80497,36713107,36713108,4167097,42617472,42492167,45591834,42492168,42617473,45562721,4145719,42617470,42492165,45596576,42492173,42617478,42617479,42492174,45582144)

) I
) C UNION ALL 
SELECT 1 as codeset_id, c.concept_id FROM (select distinct I.concept_id FROM
( 
  select concept_id from @vocabulary_database_schema.CONCEPT where concept_id in (46273644,4069660,4004776,4062498,440518,4069806,4049120,4002803,45770931,4002804,4001119,4001118,4001621,4046505,4003138,4001116,4003139,44782607,4001115,44783946,4116325,4088768,4056354,4147222,4058627,4176400,77963,4082503,4311402,380818,31668,261116,192422,4286676,140823,4174385,4001819,133002,135350,136511,141662,141944,141666,134738,133570,133573,77644,4100824,4098464,4126446,4267437,4302582,4297446,377368,74737,4222723,314147,4320803,4113424,4053285,434143,193807,4061819,4005593,45773388,4103313,4119774,4005616,77355,75628,436782,77955,72997,4326828,36717640,4289309,4100152,35623051,4006963,4004646,4114976,4007427,433022,4000968,4150816,4127128,140506,73021,4151867,80509,4344387,4178668,4110127,134453,4117689,46273162,4211842,4216972,4009619,4118008,4344258,46273620,4184657,73560,40490403,4317278,441946,443110,4178431,132416,4121803,79144,376210,4099094,4007565,256810,4260364,4150458,80838,4345581,438531,4007426,4151883,4002155,36714236,4344376,134735,137077,46271951,134454,46270394,132414,46270433,4272934,435049,4042912,4237911,75054,439910,4076794,4180849,4253536,4301483,4119283,4071059,134460,80197,439918,435353,435055,4028991,434462,4097018,4004638,4148896,4111483,4111484,4195318,4219258,4251774,4219609,441950,4313328,4185529,4301491,436802,438865,4134577,42536260,42539474,46273207,4151863,193863,434742,43021632,4175582,197084,36713435,4152999,4328488,381384,4153492,4159298,4143808,4279620,4003569,42709810,4299657,4337688,4105584,4003649,440195,201125,201399,436805,4008737,314463,4187364,377085,73866,255362,141124,45770736,444437,4316347,4134614,321109,196217,198249,376793,140526,23868,372424,380510,439394,4243365,200837,4175814,132724,4337941,4322316,375921,432725,4130372,440196,4032939,442799,373858,134741,4033966,444421,201956,4046112,257094,4194856,133303,135061,138864,25056,374142,256811,435645,436806,441953,440199,198853,4027567,200831,316795,23865,441669,435646,4314399,195060,378547,74468,4309222,132446,133013,81670,193308,75356,194151,4145142,195363,4040385,4313834,433862,443913,4184499,74470,4215370,193312,201110,4279771,381949,36713434,4253808,4031766,320206,4215697,196796,440507,441962,45765628,4004129,255059,4319334,380513,4078705,196515,434153,77984,40602337,4003808,376225,197654,381115,261393,4246066,4327939,74472,73872,4215933,4308096,4066010,4107566,37397743,440508,4167532,4217299,4005764,24148,4242694,4049461,4145905,4132119,4344267,4006160,42537682,4246290,4284702,4285304,433583,4004146,4078921,197667,40480271,133569,4029277,4338827,4114978,4004785,4289756,440829,4244067,40405599,37117206,40488823,4151729,75634,4115182,4115179,4115180,4115181,4122189,4115178,4118909,4067766,4278672,4185758,46270317,4005275,4102401,40481632,4218764,4115213,4239487,135466,4297894,37396333,4204199,4002820,4145173,4110252,4028941,194149,4149584,378533,4318653,74731,4069318,440207,196528,4002617,4005933,4005591,4005592,4109197,4067774,81390,4069306,4223399,4173780,193587,4344500,4279548,46270485,4007090,4005136,4047351,76508,4002809,4001626,4001627,4001125,4002808,4001124,4176946,4069184,378848,4022201,75048,4345577,4102846,4290978,441103,4145016,435903,4150193,4230824,4029633,435633,4007429,4004648,4003476,4005139,4228490,40420291,433585,4041695,4003980,4109493,81379,4004623,438552,436513,138538,441676,433588,435653,4218298,200200,4023960,4319903,4246469,442641,4007087,4009631,4114979,4111487,201121,258540,439412,432798,441394,80187,44783589,197656,4002956,4052685,381114,376512,140520,378849,4005135,4147784,45757259,441126,46271763,4233830,46271771,4111626,46271765,4220238,4113600,4122188,4174996,4220676,78236,4208264,442752,4168796,438836,436223,435902,432716,201675,74740,73318,79914,80800,76801,378548,79126,4002625,442087,132412,4010333,4067768,4002133,4003482,75070,4003479,4004624,133859,133294,45757678,73854,4170135,201397,4069320,4326589,4192851,4100823,4317288,4147680,4101118,4004792,73300,77665,73580,4216873,4003487,201111,440828,378523,138845,4145158,4164922,4152852,78238,4118013,4122184,4121930,4122183,4118012,4115168,4118011,4117692,76207,45766159,4068847,4098463,4328365,4111485,4110273,4111309,4166666,437657,4005289,193306,4007736,4023985,4344381,133848,72421,4259117,4283381,381677,4136209,377659,40482936,378839,40482937,4003820,4150456,4214076,4188441,37111502,4069651,4069953,4069652,4067885,4112302,4109087,40441585,45766818,45771402,4284844,4068848,4162283,4145112,4135715,4347174,4347302,442334,74728,4115164,443284,4122179,4115163,4118007,73301,4001478,4147373,40548161,438242,4164222,320835,4164551,374466,378840,435626,134461,436812,432432,4341231,4002792,4133327,77653,4215217,4304838,763891,4114974,4004635,4007081,4007082,4006587,4006457,4006586,4148897,4148557,80626,4001970,4001304,4001969,4003318,4003315,4001302,4002975,4001301,380839,4307885,4245842,4002306,437655,197096,45757433,4005469,4123290,443221,4145168,40403168,315069,312723,198246,438244,4037874,192433,4139587,4309804,134743,4152998,321107,313007,4035467,4207968,4197544,4113306,433592,4187370,138553,22426,4079975,4109796,4068969,4166587,76797,4342875,4109612,443220,4173657,4108905,4169977,4109625,4100723,4266662,4005286,4007583,4007584,444242,4338117,4002480,40406662,4309304,4318409,136516,4035494,4113455,437093,319921,4009156,4153293,4006101,4245646,4088076,45763578,79127,314457,313006,4156959,313005,4263510,4338242,4035808,4185093,259123,4005622,74150,4006107,4113438,4316227,76819,201388,75652,438250,4162450,4186285,435357,4069654,441108,4345598,372727,4210998,4103387,4000982,36716270,72405,40305987,4114975,4006589,4168853,4100815,77076,4238810,4100733,432431,4187240,75909,4160354,444115,442256,253549,4344386,136779,44782620,77635,40482662,72986,137275,4244662,37119234,43531054,4028058,77630,4040720,376208,4093228,4090616,76191,77365,4102833,4251327,313867,4170862,4176135,4235773,4033089,4067765,4004644,4007425,4308093,4110130,4069182,134757,4197547,4040640,4175621,4147788,4259147,79145,4109624,4108901,4120330,4108900,432419,4145177,437979,73008,4347178,4116324,4194889,134141,46270395,137964,137367,132718,46270396,136205,4347296,4272171,4109043,4005755,133861,40492466,46269853,4109045,46269855,46269856,135923,46269854,134144,4109962,4077901,321119,4068113,4196401,4193176,4126064,4125938,4121934,4125939,4125937,4121935,4121597,4121598,73001,4002813,4347291,46273643,46270387,46270388,46270415,46270389,46273515,46270390,4099828,23304,133566,373852,4302754,376938,4266330,135287,37018928,72413,439907,73574,4173142,4149224,134452,4223016,4069653,75920,75910,4003466,4324851,4049140,437359,37399590,75354,78257,78308,432594,4344379,141663,133853,138847,137648,140191,134137,133003,133296,4067775,4067848,46271915,4069528,46270402,46270409,46270403,46270410,74739,81403,80502,42538151,4002134,4003483,4002994,4001445,4001632,40481180,138525,4024561,4009890,432719,4001654,4080368,257660,4111482,4114973,4110269,433000,315922,73571,4115176,40480160,440511,4118017,440812,45766971,45767040,45766970,45767042,434140,4117701,4115175,436206,4009506,440822,437080,4053013)

) I
) C
;

with primary_events (event_id, person_id, start_date, end_date, op_start_date, op_end_date, visit_occurrence_id) as
(
-- Begin Primary Events
select P.ordinal as event_id, P.person_id, P.start_date, P.end_date, op_start_date, op_end_date, cast(P.visit_occurrence_id as bigint) as visit_occurrence_id
FROM
(
  select E.person_id, E.start_date, E.end_date,
         row_number() OVER (PARTITION BY E.person_id ORDER BY E.sort_date ASC) ordinal,
         OP.observation_period_start_date as op_start_date, OP.observation_period_end_date as op_end_date, cast(E.visit_occurrence_id as bigint) as visit_occurrence_id
  FROM 
  (
  -- Begin Condition Occurrence Criteria
SELECT C.person_id, C.condition_occurrence_id as event_id, C.condition_start_date as start_date, COALESCE(C.condition_end_date, DATEADD(day,1,C.condition_start_date)) as end_date,
  C.visit_occurrence_id, C.condition_start_date as sort_date
FROM 
(
  SELECT co.* 
  FROM @cdm_database_schema.CONDITION_OCCURRENCE co
  JOIN #Codesets cs on (co.condition_concept_id = cs.concept_id and cs.codeset_id = 0)
) C
JOIN @cdm_database_schema.PERSON P on C.person_id = P.person_id
WHERE C.condition_start_date >= DATEFROMPARTS(2018, 1, 1)
AND YEAR(C.condition_start_date) - P.year_of_birth >= 40
-- End Condition Occurrence Criteria

  ) E
	JOIN @cdm_database_schema.observation_period OP on E.person_id = OP.person_id and E.start_date >=  OP.observation_period_start_date and E.start_date <= op.observation_period_end_date
  WHERE DATEADD(day,0,OP.OBSERVATION_PERIOD_START_DATE) <= E.START_DATE AND DATEADD(day,0,E.START_DATE) <= OP.OBSERVATION_PERIOD_END_DATE
) P

-- End Primary Events

)
SELECT event_id, person_id, start_date, end_date, op_start_date, op_end_date, visit_occurrence_id
INTO #qualified_events
FROM 
(
  select pe.event_id, pe.person_id, pe.start_date, pe.end_date, pe.op_start_date, pe.op_end_date, row_number() over (partition by pe.person_id order by pe.start_date ASC) as ordinal, cast(pe.visit_occurrence_id as bigint) as visit_occurrence_id
  FROM primary_events pe
  
) QE

;

--- Inclusion Rule Inserts

select 0 as inclusion_rule_id, person_id, event_id
INTO #Inclusion_0
FROM 
(
  select pe.person_id, pe.event_id
  FROM #qualified_events pe
  
JOIN (
-- Begin Criteria Group
select 0 as index_id, person_id, event_id
FROM
(
  select E.person_id, E.event_id 
  FROM #qualified_events E
  INNER JOIN
  (
    -- Begin Correlated Criteria
select 0 as index_id, p.person_id, p.event_id
from #qualified_events p
LEFT JOIN (
SELECT p.person_id, p.event_id 
FROM #qualified_events P
JOIN (
  -- Begin Condition Occurrence Criteria
SELECT C.person_id, C.condition_occurrence_id as event_id, C.condition_start_date as start_date, COALESCE(C.condition_end_date, DATEADD(day,1,C.condition_start_date)) as end_date,
  C.visit_occurrence_id, C.condition_start_date as sort_date
FROM 
(
  SELECT co.* 
  FROM @cdm_database_schema.CONDITION_OCCURRENCE co
  JOIN #Codesets cs on (co.condition_concept_id = cs.concept_id and cs.codeset_id = 1)
) C


-- End Condition Occurrence Criteria

) A on A.person_id = P.person_id  ) cc on p.person_id = cc.person_id and p.event_id = cc.event_id
GROUP BY p.person_id, p.event_id
HAVING COUNT(cc.event_id) = 0
-- End Correlated Criteria

  ) CQ on E.person_id = CQ.person_id and E.event_id = CQ.event_id
  GROUP BY E.person_id, E.event_id
  HAVING COUNT(index_id) = 1
) G
-- End Criteria Group
) AC on AC.person_id = pe.person_id AND AC.event_id = pe.event_id
) Results
;

SELECT inclusion_rule_id, person_id, event_id
INTO #inclusion_events
FROM (select inclusion_rule_id, person_id, event_id from #Inclusion_0) I;
TRUNCATE TABLE #Inclusion_0;
DROP TABLE #Inclusion_0;


with cteIncludedEvents(event_id, person_id, start_date, end_date, op_start_date, op_end_date, ordinal) as
(
  SELECT event_id, person_id, start_date, end_date, op_start_date, op_end_date, row_number() over (partition by person_id order by start_date ASC) as ordinal
  from
  (
    select Q.event_id, Q.person_id, Q.start_date, Q.end_date, Q.op_start_date, Q.op_end_date, SUM(coalesce(POWER(cast(2 as bigint), I.inclusion_rule_id), 0)) as inclusion_rule_mask
    from #qualified_events Q
    LEFT JOIN #inclusion_events I on I.person_id = Q.person_id and I.event_id = Q.event_id
    GROUP BY Q.event_id, Q.person_id, Q.start_date, Q.end_date, Q.op_start_date, Q.op_end_date
  ) MG -- matching groups
{1 != 0}?{
  -- the matching group with all bits set ( POWER(2,# of inclusion rules) - 1 = inclusion_rule_mask
  WHERE (MG.inclusion_rule_mask = POWER(cast(2 as bigint),1)-1)
}
)
select event_id, person_id, start_date, end_date, op_start_date, op_end_date
into #included_events
FROM cteIncludedEvents Results

;



-- generate cohort periods into #final_cohort
with cohort_ends (event_id, person_id, end_date) as
(
	-- cohort exit dates
  -- By default, cohort exit at the event's op end date
select event_id, person_id, op_end_date as end_date from #included_events
),
first_ends (person_id, start_date, end_date) as
(
	select F.person_id, F.start_date, F.end_date
	FROM (
	  select I.event_id, I.person_id, I.start_date, E.end_date, row_number() over (partition by I.person_id, I.event_id order by E.end_date) as ordinal 
	  from #included_events I
	  join cohort_ends E on I.event_id = E.event_id and I.person_id = E.person_id and E.end_date >= I.start_date
	) F
	WHERE F.ordinal = 1
)
select person_id, start_date, end_date
INTO #cohort_rows
from first_ends;

with cteEndDates (person_id, end_date) AS -- the magic
(	
	SELECT
		person_id
		, DATEADD(day,-1 * 0, event_date)  as end_date
	FROM
	(
		SELECT
			person_id
			, event_date
			, event_type
			, MAX(start_ordinal) OVER (PARTITION BY person_id ORDER BY event_date, event_type ROWS UNBOUNDED PRECEDING) AS start_ordinal 
			, ROW_NUMBER() OVER (PARTITION BY person_id ORDER BY event_date, event_type) AS overall_ord
		FROM
		(
			SELECT
				person_id
				, start_date AS event_date
				, -1 AS event_type
				, ROW_NUMBER() OVER (PARTITION BY person_id ORDER BY start_date) AS start_ordinal
			FROM #cohort_rows
		
			UNION ALL
		

			SELECT
				person_id
				, DATEADD(day,0,end_date) as end_date
				, 1 AS event_type
				, NULL
			FROM #cohort_rows
		) RAWDATA
	) e
	WHERE (2 * e.start_ordinal) - e.overall_ord = 0
),
cteEnds (person_id, start_date, end_date) AS
(
	SELECT
		 c.person_id
		, c.start_date
		, MIN(e.end_date) AS end_date
	FROM #cohort_rows c
	JOIN cteEndDates e ON c.person_id = e.person_id AND e.end_date >= c.start_date
	GROUP BY c.person_id, c.start_date
)
select person_id, min(start_date) as start_date, end_date
into #final_cohort
from cteEnds
group by person_id, end_date
;

DELETE FROM @target_database_schema.@target_cohort_table where cohort_definition_id = @target_cohort_id;
INSERT INTO @target_database_schema.@target_cohort_table (cohort_definition_id, subject_id, cohort_start_date, cohort_end_date)
select @target_cohort_id as cohort_definition_id, person_id, start_date, end_date 
FROM #final_cohort CO
;

{0 != 0}?{
-- BEGIN: Censored Stats

delete from @results_database_schema.cohort_censor_stats where cohort_definition_id = @target_cohort_id;

-- END: Censored Stats
}
{0 != 0 & 1 != 0}?{

-- Create a temp table of inclusion rule rows for joining in the inclusion rule impact analysis

select cast(rule_sequence as int) as rule_sequence
into #inclusion_rules
from (
  SELECT CAST(0 as int) as rule_sequence
) IR;


-- Find the event that is the 'best match' per person.  
-- the 'best match' is defined as the event that satisfies the most inclusion rules.
-- ties are solved by choosing the event that matches the earliest inclusion rule, and then earliest.

select q.person_id, q.event_id
into #best_events
from #qualified_events Q
join (
	SELECT R.person_id, R.event_id, ROW_NUMBER() OVER (PARTITION BY R.person_id ORDER BY R.rule_count DESC,R.min_rule_id ASC, R.start_date ASC) AS rank_value
	FROM (
		SELECT Q.person_id, Q.event_id, COALESCE(COUNT(DISTINCT I.inclusion_rule_id), 0) AS rule_count, COALESCE(MIN(I.inclusion_rule_id), 0) AS min_rule_id, Q.start_date
		FROM #qualified_events Q
		LEFT JOIN #inclusion_events I ON q.person_id = i.person_id AND q.event_id = i.event_id
		GROUP BY Q.person_id, Q.event_id, Q.start_date
	) R
) ranked on Q.person_id = ranked.person_id and Q.event_id = ranked.event_id
WHERE ranked.rank_value = 1
;

-- modes of generation: (the same tables store the results for the different modes, identified by the mode_id column)
-- 0: all events
-- 1: best event


-- BEGIN: Inclusion Impact Analysis - event
-- calculte matching group counts
delete from @results_database_schema.cohort_inclusion_result where cohort_definition_id = @target_cohort_id and mode_id = 0;
insert into @results_database_schema.cohort_inclusion_result (cohort_definition_id, inclusion_rule_mask, person_count, mode_id)
select @target_cohort_id as cohort_definition_id, inclusion_rule_mask, count_big(*) as person_count, 0 as mode_id
from
(
  select Q.person_id, Q.event_id, CAST(SUM(coalesce(POWER(cast(2 as bigint), I.inclusion_rule_id), 0)) AS bigint) as inclusion_rule_mask
  from #qualified_events Q
  LEFT JOIN #inclusion_events I on q.person_id = i.person_id and q.event_id = i.event_id
  GROUP BY Q.person_id, Q.event_id
) MG -- matching groups
group by inclusion_rule_mask
;

-- calculate gain counts 
delete from @results_database_schema.cohort_inclusion_stats where cohort_definition_id = @target_cohort_id and mode_id = 0;
insert into @results_database_schema.cohort_inclusion_stats (cohort_definition_id, rule_sequence, person_count, gain_count, person_total, mode_id)
select @target_cohort_id as cohort_definition_id, ir.rule_sequence, coalesce(T.person_count, 0) as person_count, coalesce(SR.person_count, 0) gain_count, EventTotal.total, 0 as mode_id
from #inclusion_rules ir
left join
(
  select i.inclusion_rule_id, count_big(i.event_id) as person_count
  from #qualified_events Q
  JOIN #inclusion_events i on Q.person_id = I.person_id and Q.event_id = i.event_id
  group by i.inclusion_rule_id
) T on ir.rule_sequence = T.inclusion_rule_id
CROSS JOIN (select count(*) as total_rules from #inclusion_rules) RuleTotal
CROSS JOIN (select count_big(event_id) as total from #qualified_events) EventTotal
LEFT JOIN @results_database_schema.cohort_inclusion_result SR on SR.mode_id = 0 AND SR.cohort_definition_id = @target_cohort_id AND (POWER(cast(2 as bigint),RuleTotal.total_rules) - POWER(cast(2 as bigint),ir.rule_sequence) - 1) = SR.inclusion_rule_mask -- POWER(2,rule count) - POWER(2,rule sequence) - 1 is the mask for 'all except this rule'
;

-- calculate totals
delete from @results_database_schema.cohort_summary_stats where cohort_definition_id = @target_cohort_id and mode_id = 0;
insert into @results_database_schema.cohort_summary_stats (cohort_definition_id, base_count, final_count, mode_id)
select @target_cohort_id as cohort_definition_id, PC.total as person_count, coalesce(FC.total, 0) as final_count, 0 as mode_id
FROM
(select count_big(event_id) as total from #qualified_events) PC,
(select sum(sr.person_count) as total
  from @results_database_schema.cohort_inclusion_result sr
  CROSS JOIN (select count(*) as total_rules from #inclusion_rules) RuleTotal
  where sr.mode_id = 0 and sr.cohort_definition_id = @target_cohort_id and sr.inclusion_rule_mask = POWER(cast(2 as bigint),RuleTotal.total_rules)-1
) FC
;

-- END: Inclusion Impact Analysis - event

-- BEGIN: Inclusion Impact Analysis - person
-- calculte matching group counts
delete from @results_database_schema.cohort_inclusion_result where cohort_definition_id = @target_cohort_id and mode_id = 1;
insert into @results_database_schema.cohort_inclusion_result (cohort_definition_id, inclusion_rule_mask, person_count, mode_id)
select @target_cohort_id as cohort_definition_id, inclusion_rule_mask, count_big(*) as person_count, 1 as mode_id
from
(
  select Q.person_id, Q.event_id, CAST(SUM(coalesce(POWER(cast(2 as bigint), I.inclusion_rule_id), 0)) AS bigint) as inclusion_rule_mask
  from #best_events Q
  LEFT JOIN #inclusion_events I on q.person_id = i.person_id and q.event_id = i.event_id
  GROUP BY Q.person_id, Q.event_id
) MG -- matching groups
group by inclusion_rule_mask
;

-- calculate gain counts 
delete from @results_database_schema.cohort_inclusion_stats where cohort_definition_id = @target_cohort_id and mode_id = 1;
insert into @results_database_schema.cohort_inclusion_stats (cohort_definition_id, rule_sequence, person_count, gain_count, person_total, mode_id)
select @target_cohort_id as cohort_definition_id, ir.rule_sequence, coalesce(T.person_count, 0) as person_count, coalesce(SR.person_count, 0) gain_count, EventTotal.total, 1 as mode_id
from #inclusion_rules ir
left join
(
  select i.inclusion_rule_id, count_big(i.event_id) as person_count
  from #best_events Q
  JOIN #inclusion_events i on Q.person_id = I.person_id and Q.event_id = i.event_id
  group by i.inclusion_rule_id
) T on ir.rule_sequence = T.inclusion_rule_id
CROSS JOIN (select count(*) as total_rules from #inclusion_rules) RuleTotal
CROSS JOIN (select count_big(event_id) as total from #best_events) EventTotal
LEFT JOIN @results_database_schema.cohort_inclusion_result SR on SR.mode_id = 1 AND SR.cohort_definition_id = @target_cohort_id AND (POWER(cast(2 as bigint),RuleTotal.total_rules) - POWER(cast(2 as bigint),ir.rule_sequence) - 1) = SR.inclusion_rule_mask -- POWER(2,rule count) - POWER(2,rule sequence) - 1 is the mask for 'all except this rule'
;

-- calculate totals
delete from @results_database_schema.cohort_summary_stats where cohort_definition_id = @target_cohort_id and mode_id = 1;
insert into @results_database_schema.cohort_summary_stats (cohort_definition_id, base_count, final_count, mode_id)
select @target_cohort_id as cohort_definition_id, PC.total as person_count, coalesce(FC.total, 0) as final_count, 1 as mode_id
FROM
(select count_big(event_id) as total from #best_events) PC,
(select sum(sr.person_count) as total
  from @results_database_schema.cohort_inclusion_result sr
  CROSS JOIN (select count(*) as total_rules from #inclusion_rules) RuleTotal
  where sr.mode_id = 1 and sr.cohort_definition_id = @target_cohort_id and sr.inclusion_rule_mask = POWER(cast(2 as bigint),RuleTotal.total_rules)-1
) FC
;

-- END: Inclusion Impact Analysis - person

TRUNCATE TABLE #best_events;
DROP TABLE #best_events;

TRUNCATE TABLE #inclusion_rules;
DROP TABLE #inclusion_rules;
}



TRUNCATE TABLE #cohort_rows;
DROP TABLE #cohort_rows;

TRUNCATE TABLE #final_cohort;
DROP TABLE #final_cohort;

TRUNCATE TABLE #inclusion_events;
DROP TABLE #inclusion_events;

TRUNCATE TABLE #qualified_events;
DROP TABLE #qualified_events;

TRUNCATE TABLE #included_events;
DROP TABLE #included_events;

TRUNCATE TABLE #Codesets;
DROP TABLE #Codesets;

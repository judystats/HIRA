The source code for most of the JDBC drivers included in this package can be obtained from GitHub:

Microsoft SQL Server JDBC driver: https://github.com/Microsoft/mssql-jdbc

PostgresSQL JDBC driver: https://github.com/pgjdbc/pgjdbc

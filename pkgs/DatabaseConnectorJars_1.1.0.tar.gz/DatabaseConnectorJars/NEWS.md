DatabaseConnectorJars 1.1.0
===========================

Changes: 

1. Dropped Starschema BigQuery driver, now that newer Simba driver is available. Cannot include Simba driver because of EULA restrictions.

2. Updated RedShift driver

3. Updated PostgreSQL driver

4. Updated Oracle driver



DatabaseConnectorJars 1.0.0
===========================

Changes: initial submission to CRAN

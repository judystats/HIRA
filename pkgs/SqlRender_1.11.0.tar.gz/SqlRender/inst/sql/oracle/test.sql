{DEFAULT @some_id = 123}

SELECT a FROM my_table WHERE my_id = @some_id;

library(testthat)
library(ParallelLogger)
test_check("ParallelLogger")
